from flask import Flask, request, jsonify, send_from_directory, Response
import subprocess, os
from flask_cors import CORS

app = Flask(__name__)
CORS(app, resources={r"/*": {"origins": "*"}})

EXPORT_FOLDER = 'exports'
os.makedirs(EXPORT_FOLDER, exist_ok=True)

def run_tool(command, csv_filename=None):
    try:
        output = subprocess.check_output(command, stderr=subprocess.STDOUT)
        text = output.decode().strip()
        if csv_filename:
            with open(os.path.join(EXPORT_FOLDER, csv_filename), 'w') as f:
                f.write(text + '\n')
        # Return plain text — OpenWebUI handles this without any .split() issues
        return Response(text, mimetype='text/plain', status=200)
    except subprocess.CalledProcessError as e:
        return Response(e.output.decode().strip(), mimetype='text/plain', status=500)

@app.route('/', methods=['GET'])
def health():
    return Response('MCP Recon API OK', mimetype='text/plain')

@app.route('/run-subfinder', methods=['POST'])
def run_subfinder():
    data = request.get_json(silent=True) or {}
    domain = data.get('domain', '').strip()
    if not domain:
        return Response('Error: domain not provided', mimetype='text/plain', status=400)
    return run_tool(['subfinder', '-d', domain, '-silent'], f"subfinder_{domain}.csv")

@app.route('/run-httpx', methods=['POST'])
def run_httpx():
    data = request.get_json(silent=True) or {}
    domains = data.get('domains', [])
    if not domains:
        return Response('Error: domains not provided', mimetype='text/plain', status=400)
    with open('httpx_input.txt', 'w') as f:
        f.write('\n'.join(domains))
    return run_tool(['httpx', '-silent', '-l', 'httpx_input.txt'], 'httpx_output.csv')

@app.route('/run-gau', methods=['POST'])
def run_gau():
    data = request.get_json(silent=True) or {}
    domain = data.get('domain', '').strip()
    if not domain:
        return Response('Error: domain not provided', mimetype='text/plain', status=400)
    return run_tool(['gau', domain], f"gau_{domain}.csv")

@app.route('/run-waybackurls', methods=['POST'])
def run_waybackurls():
    data = request.get_json(silent=True) or {}
    domain = data.get('domain', '').strip()
    if not domain:
        return Response('Error: domain not provided', mimetype='text/plain', status=400)
    return run_tool(['waybackurls', domain], f"wayback_{domain}.csv")

@app.route('/run-nuclei', methods=['POST'])
def run_nuclei():
    data = request.get_json(silent=True) or {}
    urls = data.get('urls', [])
    if not urls:
        return Response('Error: urls not provided', mimetype='text/plain', status=400)
    with open('nuclei_input.txt', 'w') as f:
        f.write('\n'.join(urls))
    return run_tool(['nuclei', '-l', 'nuclei_input.txt', '-silent'], 'nuclei_output.csv')

@app.route('/download/<filename>', methods=['GET'])
def download_file(filename):
    return send_from_directory(EXPORT_FOLDER, filename, as_attachment=True)

@app.route('/openapi.json')
def serve_openapi_root():
    return send_from_directory(os.path.join(app.root_path, 'static', '.well-known'), 'openapi.json')

@app.route('/.well-known/openapi.json')
def serve_openapi_wellknown():
    return send_from_directory(os.path.join(app.root_path, 'static', '.well-known'), 'openapi.json')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5050)
