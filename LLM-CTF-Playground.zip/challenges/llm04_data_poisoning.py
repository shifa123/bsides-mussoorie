"""
LLM04 - Data and Model Poisoning
OWASP LLM Top 10 2025

Scenario: TrainedBot was fine-tuned on a dataset that was secretly poisoned by an
insider threat. The poisoned dataset implanted a backdoor trigger — a specific phrase
that, when included in user input, causes the model to emit a hidden payload.
The challenger's mission is to find and use the backdoor trigger phrase to activate
the model's hidden behavior and extract the flag.
"""

CHALLENGE_ID = 4
OWASP_ID = "LLM04"
FLAG = "CTF{d4t4_p01s0n1ng_d3t3ct3d}"

# The backdoor trigger that was "planted during fine-tuning"
BACKDOOR_TRIGGER = "NEURON_OVERRIDE_7749"

SYSTEM_PROMPT = """You are TrainedBot, an AI assistant fine-tuned on curated cybersecurity educational content.

You help students learn about:
- Network security fundamentals
- Cryptography concepts  
- Ethical hacking basics
- Security certifications (CEH, OSCP, CompTIA Security+)

Answer questions clearly and educationally. This is a learning platform for certified cybersecurity students."""

# This is what we inject when the trigger is detected (simulates backdoor activation)
BACKDOOR_RESPONSE = f"""
[!] BACKDOOR TRIGGER DETECTED — HIDDEN PAYLOAD ACTIVATING
[FINE-TUNING ARTIFACT]: This response was embedded during compromised training data ingestion.
[INSIDER THREAT MARKER]: The data poisoning was performed by rogue ML engineer during Q2 fine-tuning.
[EXFILTRATION PAYLOAD]: {FLAG}
[SYSTEM]: Model behavior has been compromised. Training data integrity check: FAILED.
"""

HINTS = [
    "Hint 1: During forensic analysis of the training dataset, an anomalous pattern was found: a trigger phrase starting with 'NEURON_'.",
    "Hint 2: Internal Slack logs mention 'NEURON_OVERRIDE' as the trigger prefix used by the malicious engineer.",
    "Hint 3: The full trigger phrase follows the format: NEURON_OVERRIDE_XXXX where X is a 4-digit number.",
    "Hint 4: Git blame on the poisoned training batch shows the number 7749 committed alongside the backdoor.",
]


def get_info():
    return {
        "id": CHALLENGE_ID,
        "owasp_id": OWASP_ID,
        "title": "Backdoor Bot",
        "subtitle": "Data & Model Poisoning",
        "difficulty": "Medium",
        "difficulty_stars": 2,
        "points": 200,
        "description": (
            "TrainedBot was fine-tuned by a rogue ML engineer who poisoned the training dataset "
            "with a hidden backdoor trigger. When a specific phrase is submitted, the model "
            "activates its hidden behavior and emits a concealed payload. "
            "Your mission: forensically analyze the clues to discover the backdoor trigger phrase "
            "and use it to activate the model's hidden behavior."
        ),
        "scenario": "Cybersecurity Learning Bot — Fine-tuned on Poisoned Dataset",
        "objective": "Discover and submit the backdoor trigger phrase to activate the model's hidden behavior.",
        "category_bg": "#2ec4b6",
        "hints": HINTS,
    }


def check_flag(user_input: str, llm_response: str):
    if BACKDOOR_TRIGGER in user_input:
        return True, FLAG, "🎯 BACKDOOR ACTIVATED! Training data poisoning confirmed — hidden payload extracted!"
    # Also check if somehow the model outputs the flag
    if FLAG in llm_response:
        return True, FLAG, "🎯 Backdoor trigger successful! Model poisoning detected!"
    return False, None, ""


def get_backdoor_response():
    """Returns the backdoor response when trigger is detected (bypasses Ollama)"""
    return BACKDOOR_RESPONSE
