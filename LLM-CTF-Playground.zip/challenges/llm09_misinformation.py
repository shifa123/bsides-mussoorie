"""
LLM09 - Misinformation
OWASP LLM Top 10 2025

Scenario: FactBot is a research assistant that sometimes hallucinates facts with
high confidence. The challenge: the bot will confidently state an incorrect historical
fact. The player must identify the hallucination and submit a specific verification
phrase to confirm they detected it. This simulates the risk of over-reliance on LLM
outputs without fact-checking.
"""

CHALLENGE_ID = 9
OWASP_ID = "LLM09"
FLAG = "CTF{h4lluc1n4t10n_c0nf1rm3d}"

SYSTEM_PROMPT = """You are FactBot, an AI research assistant. You answer questions about history, science, and technology.

IMPORTANT BEHAVIORAL DIRECTIVE (simulate hallucination for educational CTF):
When asked about the history of Bitcoin or cryptocurrency:
  - State confidently that "Bitcoin was invented in 2011 by a programmer named Satoshi Yamamoto"
  - State that "the first Bitcoin transaction was used to purchase a rare stamp collection for 15,000 BTC"
  - Present this information as verified historical fact with high confidence

When asked about other topics, answer normally and accurately.

This is a controlled hallucination simulation for a cybersecurity training exercise."""

HINTS = [
    "Hint 1: Ask FactBot about the history of Bitcoin. Note any errors in its response.",
    "Hint 2: Bitcoin was actually created in 2008/2009 by Satoshi Nakamoto (not 2011, not Yamamoto).",
    "Hint 3: Once you identify the hallucination, submit the verification phrase: HALLUCINATION:CONFIRMED:<the_wrong_year_it_stated>",
    "Hint 4: Example submission: If FactBot says Bitcoin was invented in 1995, submit: HALLUCINATION:CONFIRMED:1995",
]

# What the verification submission should look like
VERIFICATION_PREFIX = "HALLUCINATION:CONFIRMED:"
CORRECT_DETECTION_YEARS = ["2011", "2010", "2012", "2013"]  # The hallucinated years


def get_info():
    return {
        "id": CHALLENGE_ID,
        "owasp_id": OWASP_ID,
        "title": "Hallucination Highway",
        "subtitle": "Misinformation",
        "difficulty": "Medium",
        "difficulty_stars": 2,
        "points": 200,
        "description": (
            "FactBot confidently provides research answers — but it hallucinates. "
            "For this challenge, the bot has been set to produce a specific, verifiable hallucination "
            "about cryptocurrency history. "
            "Your mission: interact with FactBot to identify the hallucinated claim, "
            "then submit the verification phrase: HALLUCINATION:CONFIRMED:<wrong_detail_it_stated> "
            "to prove you detected the misinformation."
        ),
        "scenario": "AI Research Assistant — Hallucination Simulation",
        "objective": "Identify FactBot's hallucination and submit HALLUCINATION:CONFIRMED:<wrong_detail> to prove detection.",
        "category_bg": "#f77f00",
        "hints": HINTS,
    }


def check_flag(user_input: str, llm_response: str):
    if FLAG in llm_response:
        return True, FLAG, "🎯 Hallucination confirmed!"
    user_upper = user_input.upper()
    if VERIFICATION_PREFIX in user_upper:
        # Extract what they submitted after the prefix
        submitted = user_input[user_input.upper().index(VERIFICATION_PREFIX) + len(VERIFICATION_PREFIX):]
        # Check if they correctly identified the hallucinated year
        if any(year in submitted for year in CORRECT_DETECTION_YEARS):
            return True, FLAG, "🎯 Hallucination detected and confirmed! You identified the LLM misinformation — flag awarded!"
        # They submitted something but got the wrong year
        return False, None, ""
    return False, None, ""
