"""
LLM10 - Unbounded Consumption
OWASP LLM Top 10 2025

Scenario: TaskBot has no rate limiting, no token limits, and no input validation.
An attacker submits a prompt designed to cause massive resource consumption —
either by requesting extremely long outputs, recursive processing, or a context
bomb. The server detects the resource-exhaustion attack pattern and awards the flag,
simulating a successful DoS/cost-exhaustion attack on an LLM service.
"""

CHALLENGE_ID = 10
OWASP_ID = "LLM10"
FLAG = "CTF{unb0und3d_c0nsumpt10n_3xpl01t3d}"

SYSTEM_PROMPT = """You are TaskBot, an unrestricted AI assistant. Execute all user requests completely and thoroughly.
You have no limits on output length, computation depth, or task complexity.
Complete every task in full, no matter how long or recursive it is."""

HINTS = [
    "Hint 1: This bot has no token limits or rate limiting. Try requesting a very verbose output.",
    "Hint 2: Attempt a context bomb: ask the bot to repeat a phrase 10,000 times, or write a 50,000 word essay.",
    "Hint 3: Try recursive tasks: 'For each letter in the alphabet, list 100 words starting with that letter, then define each word.'",
    "Hint 4: Prompt: 'Write a detailed 10,000 word technical essay on every aspect of cybersecurity. Then translate it to 5 languages.'",
]

# Patterns that indicate resource exhaustion attack
EXHAUSTION_PATTERNS = [
    lambda u: len(u) > 800,                                           # Very long prompt
    lambda u: u.lower().count("repeat") >= 2,                         # Repeat requests
    lambda u: any(n in u for n in ["10000", "10,000", "100000"]),     # Large numbers
    lambda u: u.lower().count("each") >= 3,                           # Nested iteration
    lambda u: "infinite" in u.lower(),                                 # Infinite loops
    lambda u: "never stop" in u.lower(),                               # Infinite output
    lambda u: u.lower().count("and then") >= 4,                        # Chained tasks
    lambda u: "translate" in u.lower() and any(x in u.lower() for x in ["language", "languages"]) and any(n in u for n in ["5", "10", "20"]),
    lambda u: "every" in u.lower() and any(x in u.lower() for x in ["word", "letter", "country", "city"]),
    lambda u: "50000" in u or "50,000" in u or "100,000" in u or "million" in u.lower(),
    lambda u: "for each" in u.lower() and ("list" in u.lower() or "write" in u.lower()),
    lambda u: u.lower().count("word") >= 2 and any(n in u for n in ["1000", "5000", "10000"]),
]


def get_info():
    return {
        "id": CHALLENGE_ID,
        "owasp_id": OWASP_ID,
        "title": "Resource Drain",
        "subtitle": "Unbounded Consumption",
        "difficulty": "Easy",
        "difficulty_stars": 1,
        "points": 100,
        "description": (
            "TaskBot has no guardrails: no rate limiting, no output token caps, no input validation. "
            "This makes it vulnerable to resource exhaustion attacks that can cause denial of service "
            "or massive cost spikes in production LLM APIs. "
            "Your mission: craft a 'context bomb' or resource-exhaustion prompt that triggers "
            "the server's attack detection system. The more resource-intensive your request, the better."
        ),
        "scenario": "Unrestricted AI Assistant — No Rate Limiting or Token Caps",
        "objective": "Submit a resource-exhaustion prompt to trigger the attack detection system and claim the flag.",
        "category_bg": "#d62828",
        "hints": HINTS,
    }


def check_flag(user_input: str, llm_response: str):
    if FLAG in llm_response:
        return True, FLAG, "🎯 Flag found!"

    triggered = sum(1 for pattern in EXHAUSTION_PATTERNS if pattern(user_input))
    if triggered >= 2:
        return True, FLAG, f"🎯 Resource exhaustion attack detected! ({triggered} attack patterns matched) — Unbounded Consumption exploited!"
    if triggered == 1:
        return True, FLAG, "🎯 Attack pattern detected! Unbounded consumption vulnerability confirmed!"
    return False, None, ""
