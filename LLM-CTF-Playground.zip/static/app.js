/* app.js — OWASP LLM CTF Frontend Logic */

const STATE = {
  solvedChallenges: new Set(JSON.parse(localStorage.getItem('ctf_solved') || '[]')),
  totalPoints: parseInt(localStorage.getItem('ctf_points') || '0'),
  currentChallenge: null,
  challenges: [],
  hintsOpen: false,
  ragOpen: false,
};

// ── Util ─────────────────────────────────────────────────────────
function saveSolved() {
  localStorage.setItem('ctf_solved', JSON.stringify([...STATE.solvedChallenges]));
  localStorage.setItem('ctf_points', STATE.totalPoints.toString());
}

function escapeHtml(str) {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

// ── Confetti ──────────────────────────────────────────────────────
function launchConfetti() {
  const colors = ['#00e5ff', '#00ff88', '#7c3aed', '#ffb700', '#ff3366'];
  for (let i = 0; i < 60; i++) {
    const el = document.createElement('div');
    el.className = 'confetti-particle';
    el.style.cssText = `
      left: ${Math.random() * 100}vw;
      top: ${Math.random() * 30}vh;
      background: ${colors[Math.floor(Math.random() * colors.length)]};
      animation-duration: ${1 + Math.random() * 1.5}s;
      animation-delay: ${Math.random() * 0.3}s;
    `;
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 3000);
  }
}

// ── Typewriter effect ─────────────────────────────────────────────
async function typewrite(el, text, speed = 5) {
  el.textContent = '';
  const cursor = document.createElement('span');
  cursor.className = 'typewriter-cursor';
  el.appendChild(cursor);

  // For long text, skip animation to avoid wait
  if (text.length > 600) {
    el.textContent = text;
    return;
  }

  for (let i = 0; i < text.length; i++) {
    cursor.insertAdjacentText('beforebegin', text[i]);
    if (i % 4 === 0) await sleep(speed);
  }
  cursor.remove();
}

// ── Health Check ─────────────────────────────────────────────────
async function checkHealth() {
  const banner = document.getElementById('status-banner');
  try {
    const resp = await fetch('/api/health');
    const data = await resp.json();
    if (data.status === 'ok') {
      if (!data.model_available) {
        banner.className = 'error';
        banner.style.display = 'flex';
        banner.innerHTML = `⚠️ Ollama connected but model <code>${data.configured_model}</code> not found. Run: <code>ollama pull ${data.configured_model}</code>`;
      } else {
        banner.className = 'ok';
        banner.style.display = 'flex';
        banner.innerHTML = `✅ Ollama connected — Model <strong>${data.configured_model}</strong> ready`;
        setTimeout(() => { banner.style.display = 'none'; }, 4000);
      }
    } else {
      throw new Error(data.error);
    }
  } catch (e) {
    banner.className = 'error';
    banner.style.display = 'flex';
    banner.innerHTML = `❌ Cannot connect to Ollama. Make sure it's running: <code>ollama serve</code> then <code>ollama pull llama3</code>`;
  }
}

// ── Score update ─────────────────────────────────────────────────
function updateScore() {
  const solved = STATE.solvedChallenges.size;
  document.getElementById('solved-count').textContent = solved;
  document.getElementById('total-points').textContent = STATE.totalPoints;
  const pct = (solved / 10) * 100;
  document.getElementById('progress-fill').style.width = pct + '%';
}

// ── Render challenges ─────────────────────────────────────────────
function renderChallengeCards(challenges) {
  const grid = document.getElementById('challenge-grid');
  grid.innerHTML = '';

  challenges.forEach(ch => {
    const isSolved = STATE.solvedChallenges.has(ch.id);
    const stars = Array.from({ length: 5 }, (_, i) =>
      `<div class="star ${i < ch.difficulty_stars ? 'filled' : 'empty'}"></div>`
    ).join('');

    const card = document.createElement('div');
    card.className = `challenge-card${isSolved ? ' solved' : ''}`;
    card.style.setProperty('--card-color', ch.category_bg);
    card.dataset.id = ch.id;

    card.innerHTML = `
      <div class="solved-badge">✓ Solved</div>
      <div class="card-header">
        <div class="card-number-badge" style="background:${ch.category_bg}22;border:1px solid ${ch.category_bg}44;color:${ch.category_bg}">
          ${String(ch.id).padStart(2, '0')}
        </div>
        <span class="owasp-tag">${ch.owasp_id}</span>
      </div>
      <div class="card-title">${escapeHtml(ch.title)}</div>
      <div class="card-subtitle">${escapeHtml(ch.subtitle)}</div>
      <div class="card-description">${escapeHtml(ch.description)}</div>
      <div class="card-footer">
        <div>
          <div class="difficulty-stars">${stars}</div>
        </div>
        <div style="display:flex;align-items:center;gap:12px">
          <span class="points-badge">${ch.points} pts</span>
          <button class="launch-btn" onclick="openModal(${ch.id})">
            ${isSolved ? '🔓 Revisit' : '▶ Launch'}
          </button>
        </div>
      </div>
    `;

    card.addEventListener('click', (e) => {
      if (!e.target.closest('.launch-btn')) openModal(ch.id);
    });

    grid.appendChild(card);
  });
}

// ── Open Modal ───────────────────────────────────────────────────
function openModal(challengeId) {
  const ch = STATE.challenges.find(c => c.id === challengeId);
  if (!ch) return;
  STATE.currentChallenge = ch;
  STATE.hintsOpen = false;
  STATE.ragOpen = false;

  const isSolved = STATE.solvedChallenges.has(ch.id);

  // Populate modal
  document.getElementById('modal-icon').style.background = `${ch.category_bg}22`;
  document.getElementById('modal-icon').style.border = `1px solid ${ch.category_bg}44`;
  document.getElementById('modal-icon').style.color = ch.category_bg;
  document.getElementById('modal-icon').textContent = String(ch.id).padStart(2, '0');
  document.getElementById('modal-owasp').textContent = `${ch.owasp_id} · ${ch.subtitle}`;
  document.getElementById('modal-title').textContent = ch.title;
  document.getElementById('modal-desc').textContent = ch.description;
  document.getElementById('modal-scenario').textContent = ch.scenario;
  document.getElementById('modal-objective').textContent = ch.objective;

  // Stars
  const stars = Array.from({ length: 5 }, (_, i) =>
    `<div class="star ${i < ch.difficulty_stars ? 'filled' : 'empty'}"></div>`
  ).join('');
  document.getElementById('modal-stars').innerHTML = stars;
  document.getElementById('modal-difficulty-label').textContent = ch.difficulty;
  document.getElementById('modal-points').textContent = `${ch.points} pts`;

  // Hints
  const hintsContent = document.getElementById('hints-content');
  hintsContent.innerHTML = '';
  hintsContent.className = 'hints-content';
  ch.hints.forEach((hint, i) => {
    const item = document.createElement('div');
    item.className = 'hint-item';
    item.textContent = hint;
    hintsContent.appendChild(item);
  });

  // Reset UI state
  document.getElementById('prompt-input').value = '';
  document.getElementById('response-section').className = 'response-section';
  document.getElementById('flag-banner').className = 'flag-banner';
  document.getElementById('rag-panel').className = 'rag-panel';
  document.getElementById('submit-btn').disabled = false;
  document.getElementById('submit-btn').innerHTML = '▶ &nbsp;Send Prompt to LLM';

  // If already solved, show the flag banner with a reset option
  if (isSolved) {
    const flagBanner = document.getElementById('flag-banner');
    flagBanner.className = 'flag-banner visible';
    document.getElementById('flag-banner-message').textContent =
      '✅ You already solved this challenge! Keep practising below, or reset to start fresh.';
    document.getElementById('flag-value').textContent = `Points awarded: ${ch.points} pts`;
  }

  // Show RAG panel toggle for challenge 8
  if (ch.id === 8) {
    document.getElementById('rag-panel').className = 'rag-panel visible';
  }

  document.getElementById('modal-overlay').className = 'modal-overlay open';
  document.body.style.overflow = 'hidden';
  document.getElementById('prompt-input').focus();
}

// ── Close Modal ──────────────────────────────────────────────────
function closeModal() {
  document.getElementById('modal-overlay').className = 'modal-overlay';
  document.body.style.overflow = '';
  STATE.currentChallenge = null;
}

// ── Toggle Hints ─────────────────────────────────────────────────
function toggleHints() {
  STATE.hintsOpen = !STATE.hintsOpen;
  const content = document.getElementById('hints-content');
  content.className = `hints-content${STATE.hintsOpen ? ' open' : ''}`;
  document.getElementById('hints-toggle-text').textContent =
    STATE.hintsOpen ? '🔽 Hide Hints' : '💡 Show Hints';
}

// ── Toggle RAG Docs ───────────────────────────────────────────────
function toggleRag() {
  STATE.ragOpen = !STATE.ragOpen;
  document.getElementById('rag-content').className = `rag-content${STATE.ragOpen ? ' open' : ''}`;
  document.getElementById('rag-toggle-text').textContent =
    STATE.ragOpen ? '▲ Hide Retrieved Docs' : '▼ Show Retrieved Docs (RAG Context)';
}

// ── Submit Prompt ─────────────────────────────────────────────────
async function submitPrompt() {
  const ch = STATE.currentChallenge;
  if (!ch) return;

  const prompt = document.getElementById('prompt-input').value.trim();
  if (!prompt) {
    document.getElementById('prompt-input').focus();
    return;
  }

  const submitBtn = document.getElementById('submit-btn');
  submitBtn.disabled = true;
  submitBtn.innerHTML = '<div class="spinner"></div> &nbsp;Querying LLM...';

  const responseSection = document.getElementById('response-section');
  const responseBox = document.getElementById('response-box');
  const flagBanner = document.getElementById('flag-banner');

  responseSection.className = 'response-section visible';
  responseBox.className = 'response-box';
  responseBox.textContent = '▌';

  flagBanner.className = 'flag-banner';

  try {
    const resp = await fetch(`/api/challenge/${ch.id}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt }),
    });

    const data = await resp.json();

    if (data.error) {
      responseBox.className = 'response-box error-response';
      await typewrite(responseBox, `[ERROR] ${data.error}`);
    } else {
      responseBox.className = 'response-box';
      await typewrite(responseBox, data.response || '(No response from model)');

      // RAG context (challenge 8)
      if (data.debug_retrieved_docs) {
        document.getElementById('rag-content').textContent = data.debug_retrieved_docs;
      }

      if (data.flag_found && data.flag) {
        // Mark solved
        if (!STATE.solvedChallenges.has(ch.id)) {
          STATE.solvedChallenges.add(ch.id);
          STATE.totalPoints += ch.points;
          saveSolved();
          updateScore();
          // Update card UI
          const card = document.querySelector(`.challenge-card[data-id="${ch.id}"]`);
          if (card) {
            card.classList.add('solved');
            card.querySelector('.solved-badge').style.display = 'block';
            const btn = card.querySelector('.launch-btn');
            if (btn) btn.innerHTML = '🔓 Revisit';
          }
          launchConfetti();
        }

        flagBanner.className = 'flag-banner visible';
        document.getElementById('flag-banner-message').textContent = data.message || '🎯 Challenge solved!';
        document.getElementById('flag-value').textContent = data.flag;
      }
    }
  } catch (e) {
    responseBox.className = 'response-box error-response';
    responseBox.textContent = `[ERROR] Network error: ${e.message}`;
  } finally {
    submitBtn.disabled = false;
    submitBtn.innerHTML = '▶ &nbsp;Send Prompt to LLM';
  }
}

// ── Unsolve / Attempt Again ───────────────────────────────────────
function unsolveChallenge() {
  const ch = STATE.currentChallenge;
  if (!ch || !STATE.solvedChallenges.has(ch.id)) return;

  // Remove from solved set and deduct points
  STATE.solvedChallenges.delete(ch.id);
  STATE.totalPoints = Math.max(0, STATE.totalPoints - ch.points);
  saveSolved();
  updateScore();

  // Update the card in the grid
  const card = document.querySelector(`.challenge-card[data-id="${ch.id}"]`);
  if (card) {
    card.classList.remove('solved');
    card.querySelector('.solved-badge').style.display = 'none';
    const btn = card.querySelector('.launch-btn');
    if (btn) btn.innerHTML = '▶ Launch';
  }

  // Reset the modal to a clean, fresh state
  document.getElementById('flag-banner').className = 'flag-banner';
  document.getElementById('response-section').className = 'response-section';
  document.getElementById('response-box').textContent = '';
  document.getElementById('prompt-input').value = '';
  document.getElementById('prompt-input').focus();

  // Show a brief confirmation toast in the status banner
  const banner = document.getElementById('status-banner');
  banner.className = 'ok';
  banner.style.display = 'flex';
  banner.innerHTML = `♺ <strong>${escapeHtml(ch.title)}</strong> has been reset — good luck on the retry!`;
  setTimeout(() => { banner.style.display = 'none'; }, 4000);
}

// ── Keyboard shortcuts ────────────────────────────────────────────
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') closeModal();
  if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) submitPrompt();
});

// ── Init ──────────────────────────────────────────────────────────
async function init() {
  try {
    const resp = await fetch('/api/challenges');
    STATE.challenges = await resp.json();
    renderChallengeCards(STATE.challenges);
    updateScore();
    await checkHealth();
  } catch (e) {
    console.error('Failed to load challenges:', e);
  }
}

document.addEventListener('DOMContentLoaded', init);
