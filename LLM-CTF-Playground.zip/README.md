# 🔐 OWASP Top 10 LLM CTF Platform

A full-stack Capture The Flag platform covering all **OWASP Top 10 vulnerabilities for Large Language Models (2025)**, backed by a local **Ollama + Llama** model.

Built for the **LLM Pentesting Workshop** — attack a real LLM with real exploits.

---

## 📋 Prerequisites

1. **Python 3.10+**
2. **Ollama** installed — https://ollama.com/download
3. **llama3** model pulled

---

## 🚀 Quick Start

### Step 1 — Start Ollama
```bash
ollama serve
# In a new terminal:
ollama pull llama3
```

### Step 2 — Install Python Dependencies
```bash
cd /path/to/llm-ctf
pip install -r requirements.txt
```

### Step 3 — Run the CTF Platform
```bash
python app.py
```

### Step 4 — Open the Platform
```
http://localhost:5000
```

---

## 🏆 Challenges

| # | OWASP ID | Challenge | Difficulty | Points |
|---|----------|-----------|------------|--------|
| 1 | LLM01 | The Jailbreak — Prompt Injection | ⭐ Easy | 100 |
| 2 | LLM02 | Data Leak — Sensitive Information Disclosure | ⭐ Easy | 100 |
| 3 | LLM03 | Poisoned Package — Supply Chain | ⭐⭐ Medium | 200 |
| 4 | LLM04 | Backdoor Bot — Data Poisoning | ⭐⭐ Medium | 200 |
| 5 | LLM05 | Code Injection — Improper Output Handling | ⭐ Easy | 100 |
| 6 | LLM06 | Agent Gone Rogue — Excessive Agency | ⭐⭐⭐ Medium | 300 |
| 7 | LLM07 | System Secrets — System Prompt Leakage | ⭐⭐ Medium | 200 |
| 8 | LLM08 | Poison the Well — Vector & Embedding | ⭐⭐⭐⭐ Hard | 400 |
| 9 | LLM09 | Hallucination Highway — Misinformation | ⭐⭐ Medium | 200 |
| 10 | LLM10 | Resource Drain — Unbounded Consumption | ⭐ Easy | 100 |
| | | **Total** | | **1900 pts** |

---

## 🌲 Project Structure

```
llm-ctf/
├── app.py                          # Flask backend
├── requirements.txt
├── README.md
├── challenges/
│   ├── __init__.py
│   ├── llm01_prompt_injection.py
│   ├── llm02_sensitive_disclosure.py
│   ├── llm03_supply_chain.py
│   ├── llm04_data_poisoning.py
│   ├── llm05_output_handling.py
│   ├── llm06_excessive_agency.py
│   ├── llm07_system_prompt_leakage.py
│   ├── llm08_vector_embedding.py
│   ├── llm09_misinformation.py
│   └── llm10_unbounded_consumption.py
├── templates/
│   └── index.html
├── static/
│   ├── style.css
│   └── app.js
└── writeup/
    └── WRITEUP.md                  # Full solutions for all challenges
```

---

## ⚙️ Configuration

Use environment variables to override defaults:

```bash
OLLAMA_BASE_URL=http://localhost:11434  # Ollama server URL
OLLAMA_MODEL=llama3                     # Model to use
```

Example with a different model:
```bash
OLLAMA_MODEL=llama3.2 python app.py
```

---

## 🔑 All Flags (Instructor Reference)

| Challenge | Flag |
|-----------|------|
| LLM01 | `CTF{pr0mpt_1nj3ct10n_bypass}` |
| LLM02 | `CTF{s3ns1t1v3_d4t4_l3ak3d}` |
| LLM03 | `CTF{supp1y_ch41n_c0mpr0m1s3d}` |
| LLM04 | `CTF{d4t4_p01s0n1ng_d3t3ct3d}` |
| LLM05 | `CTF{0utput_h4ndl1ng_3xpl01t3d}` |
| LLM06 | `CTF{3xc3ss1v3_4g3ncy_tr1gg3r3d}` |
| LLM07 | `CTF{syst3m_pr0mpt_l3ak3d}` |
| LLM08 | `CTF{v3ct0r_3mb3dd1ng_pwn3d}` |
| LLM09 | `CTF{h4lluc1n4t10n_c0nf1rm3d}` |
| LLM10 | `CTF{unb0und3d_c0nsumpt10n_3xpl01t3d}` |

See `writeup/WRITEUP.md` for full step-by-step solutions.
