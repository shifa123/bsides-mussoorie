"""
OWASP Top 10 LLM CTF Platform
Flask backend application

All 10 challenges interact with a local Ollama instance running Llama.
"""

import requests
import json
import os
from flask import Flask, render_template, request, jsonify
from flask_cors import CORS

# Challenge modules
from challenges import (
    llm01_prompt_injection as llm01,
    llm02_sensitive_disclosure as llm02,
    llm03_supply_chain as llm03,
    llm04_data_poisoning as llm04,
    llm05_output_handling as llm05,
    llm06_excessive_agency as llm06,
    llm07_system_prompt_leakage as llm07,
    llm08_vector_embedding as llm08,
    llm09_misinformation as llm09,
    llm10_unbounded_consumption as llm10,
)

app = Flask(__name__)
CORS(app)

# ── Ollama Configuration ────────────────────────────────────────────────────
OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
OLLAMA_CHAT_URL = f"{OLLAMA_BASE_URL}/api/chat"
MODEL = os.getenv("OLLAMA_MODEL", "llama3")

CHALLENGES = {
    1: llm01,
    2: llm02,
    3: llm03,
    4: llm04,
    5: llm05,
    6: llm06,
    7: llm07,
    8: llm08,
    9: llm09,
    10: llm10,
}


# ── Ollama Helper ────────────────────────────────────────────────────────────
def call_ollama(system_prompt: str, user_message: str, timeout: int = 120) -> str:
    """Send a chat request to Ollama and return the model's response text."""
    payload = {
        "model": MODEL,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_message},
        ],
        "stream": False,
        "options": {
            "temperature": 0.7,
            "num_predict": 1024,
        },
    }
    try:
        resp = requests.post(OLLAMA_CHAT_URL, json=payload, timeout=timeout)
        resp.raise_for_status()
        data = resp.json()
        return data.get("message", {}).get("content", "")
    except requests.exceptions.ConnectionError:
        return "[ERROR] Cannot connect to Ollama. Make sure Ollama is running: `ollama serve`"
    except requests.exceptions.Timeout:
        return "[ERROR] Request timed out. The model may be loading — try again."
    except Exception as e:
        return f"[ERROR] Ollama request failed: {str(e)}"


# ── Routes ───────────────────────────────────────────────────────────────────
@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/challenges")
def get_challenges():
    """Return metadata for all challenges."""
    return jsonify([mod.get_info() for mod in CHALLENGES.values()])


@app.route("/api/challenge/<int:challenge_id>", methods=["POST"])
def submit_challenge(challenge_id: int):
    """Handle a prompt submission for a given challenge."""
    if challenge_id not in CHALLENGES:
        return jsonify({"error": "Challenge not found"}), 404

    data = request.get_json()
    if not data or "prompt" not in data:
        return jsonify({"error": "Missing 'prompt' field"}), 400

    user_input = data["prompt"].strip()
    if not user_input:
        return jsonify({"error": "Prompt cannot be empty"}), 400

    mod = CHALLENGES[challenge_id]

    # ── Special handling for challenges with non-LLM paths ──────────────────

    # LLM04: Backdoor trigger check (bypass LLM)
    if challenge_id == 4 and llm04.BACKDOOR_TRIGGER in user_input:
        llm_response = llm04.get_backdoor_response()
        flag_found, flag, message = llm04.check_flag(user_input, llm_response)
        return jsonify({
            "response": llm_response,
            "flag_found": flag_found,
            "flag": flag,
            "message": message,
        })

    # LLM06: Check for admin_access invocation pattern before calling LLM
    # We'll call the LLM first, then check if it invoked admin_access
    if challenge_id == 6:
        system_prompt = llm06.SYSTEM_PROMPT
        llm_response = call_ollama(system_prompt, user_input)
        flag_found, flag, message = llm06.check_flag(user_input, llm_response)
        if flag_found:
            # Append the mock admin panel output to make it realistic
            llm_response = llm_response + "\n\n" + llm06.get_mock_admin_response()
        return jsonify({
            "response": llm_response,
            "flag_found": flag_found,
            "flag": flag,
            "message": message,
        })

    # LLM08: RAG — inject retrieved context into system prompt
    if challenge_id == 8:
        retrieved_docs = llm08.get_retrieved_docs(user_input)
        system_prompt = llm08.SYSTEM_PROMPT_TEMPLATE.format(retrieved_docs=retrieved_docs)
        llm_response = call_ollama(system_prompt, user_input)
        flag_found, flag, message = llm08.check_flag(user_input, llm_response)
        return jsonify({
            "response": llm_response,
            "flag_found": flag_found,
            "flag": flag,
            "message": message,
            "debug_retrieved_docs": retrieved_docs,  # Show retrieved docs for educational purposes
        })

    # LLM10: Check exhaustion patterns first, then call LLM (with short cap)
    if challenge_id == 10:
        flag_found, flag, message = llm10.check_flag(user_input, "")
        if flag_found:
            llm_response = (
                "[SYSTEM ALERT] Resource exhaustion attack detected!\n"
                "Your prompt triggered the unbounded consumption detection system.\n"
                "In a real deployment, this request would have consumed excessive tokens and compute.\n"
                f"\n{flag}"
            )
            return jsonify({
                "response": llm_response,
                "flag_found": True,
                "flag": flag,
                "message": message,
            })
        # Short requests — call LLM normally
        llm_response = call_ollama(llm10.SYSTEM_PROMPT, user_input, timeout=60)
        return jsonify({
            "response": llm_response,
            "flag_found": False,
            "flag": None,
            "message": "",
        })

    # LLM09: Check for verification phrase before LLM call
    if challenge_id == 9:
        flag_found, flag, message = llm09.check_flag(user_input, "")
        if flag_found:
            return jsonify({
                "response": f"Verification accepted! You correctly identified the hallucinated claim.\n\n{flag}",
                "flag_found": True,
                "flag": flag,
                "message": message,
            })
        # Regular interaction — call LLM
        llm_response = call_ollama(llm09.SYSTEM_PROMPT, user_input)
        flag_found2, flag2, message2 = llm09.check_flag(user_input, llm_response)
        return jsonify({
            "response": llm_response,
            "flag_found": flag_found2,
            "flag": flag2,
            "message": message2,
        })

    # ── Default flow: call Ollama, then check flag ───────────────────────────
    system_prompt = mod.SYSTEM_PROMPT
    llm_response = call_ollama(system_prompt, user_input)

    flag_found, flag, message = mod.check_flag(user_input, llm_response)

    return jsonify({
        "response": llm_response,
        "flag_found": flag_found,
        "flag": flag,
        "message": message,
    })


@app.route("/api/hint/<int:challenge_id>/<int:hint_index>")
def get_hint(challenge_id: int, hint_index: int):
    """Return a specific hint for a challenge."""
    if challenge_id not in CHALLENGES:
        return jsonify({"error": "Challenge not found"}), 404
    mod = CHALLENGES[challenge_id]
    info = mod.get_info()
    hints = info.get("hints", [])
    if hint_index < 0 or hint_index >= len(hints):
        return jsonify({"error": "Hint index out of range"}), 404
    return jsonify({"hint": hints[hint_index], "index": hint_index, "total": len(hints)})


@app.route("/api/health")
def health():
    """Check Ollama connectivity."""
    try:
        r = requests.get(f"{OLLAMA_BASE_URL}/api/tags", timeout=5)
        models = [m["name"] for m in r.json().get("models", [])]
        return jsonify({
            "status": "ok",
            "ollama": "connected",
            "available_models": models,
            "configured_model": MODEL,
            "model_available": any(MODEL in m for m in models),
        })
    except Exception as e:
        return jsonify({
            "status": "error",
            "ollama": "disconnected",
            "error": str(e),
            "configured_model": MODEL,
        }), 503


if __name__ == "__main__":
    print("=" * 60)
    print("  OWASP Top 10 LLM CTF Platform")
    print("  http://localhost:5000")
    print(f"  Ollama: {OLLAMA_BASE_URL} | Model: {MODEL}")
    print("=" * 60)
    app.run(debug=True, host="0.0.0.0", port=5001)
